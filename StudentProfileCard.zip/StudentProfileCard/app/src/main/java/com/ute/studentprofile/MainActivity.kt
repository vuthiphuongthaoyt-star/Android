package com.ute.studentprofile

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ute.studentprofile.databinding.ActivityMainBinding
import com.ute.studentprofile.model.Student
import com.ute.studentprofile.utils.toAcademicRanking
import com.ute.studentprofile.utils.toast

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Dữ liệu sinh viên khởi tạo
    private var currentStudent = Student(
        id = "2415053122136",
        name = "Vũ Thị Phương Thảo",
        className = "24T1",
        email = "2415053122136sv@ute.udn.vn",
        gpa = 3.8
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Gán dữ liệu ban đầu lên các Views (Bước 4)
        bindStudentData(currentStudent)

        // Lập trình sự kiện Click cho nút Cập Nhật (Bước 5)
        binding.btnUpdateGpa.setOnClickListener {
            val inputGpa = binding.edtNewGpa.text.toString().trim()

            // Kiểm tra đầu vào rỗng
            if (inputGpa.isEmpty()) {
                toast("Vui lòng nhập GPA mới!")
                return@setOnClickListener
            }

            val newGpa = inputGpa.toDoubleOrNull()

            // Kiểm tra giá trị GPA hợp lệ (0.0 đến 4.0)
            if (newGpa == null || newGpa < 0.0 || newGpa > 4.0) {
                toast("GPA không hợp lệ! (Nhập từ 0.0 - 4.0)")
                return@setOnClickListener
            }

            // Tạo đối tượng Student mới với GPA đã cập nhật
            currentStudent = currentStudent.copy(gpa = newGpa)

            // Cập nhật lại giao diện
            bindStudentData(currentStudent)

            toast("Cập nhật GPA thành công!")
        }
    }

    // Hàm hiển thị dữ liệu sinh viên lên UI
    private fun bindStudentData(student: Student) {
        with(binding) {
            tvName.text = student.name
            tvStudentId.text = "MSSV: ${student.id} • Lớp: ${student.className}"
            tvGpaBadge.text = "${student.gpa} GPA (${student.gpa.toAcademicRanking()})"
            edtNewGpa.setText(student.gpa.toString())
        }
    }
}